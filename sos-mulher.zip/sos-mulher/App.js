import React from 'react';
import { NavigationContainer, DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import { Provider as PaperProvider, DefaultTheme as PaperDefaultTheme } from 'react-native-paper';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
  import UserScreen from './screens/UserScreen';
  import HomeScreen from './screens/HomeScreen';
  import MenuScreen from './screens/MenuScreen';
  import InformationScreen from './screens/InformationScreen';


const CombinedDefaultTheme = {
  ...PaperDefaultTheme,
  ...NavigationDefaultTheme,
  colors: {
    ...PaperDefaultTheme.colors,
    ...NavigationDefaultTheme.colors,
    primary: '#B758ED',
    text: 'blue',
    background: '#F0C8fd'
  },
};

const Tab = createMaterialBottomTabNavigator();

function App() {
  return (
    <PaperProvider theme={CombinedDefaultTheme}>

  
      <NavigationContainer theme={CombinedDefaultTheme}>
        <Tab.Navigator initialRouteName="Home">
<Tab.Screen name="Home" component={HomeScreen} options={{tabBarIcon: ({ focused, color}) => {
  return(
     <MaterialCommunityIcons name="home" size={24} color={color}/> );
    }}}/>
      <Tab.Screen name="User" component={UserScreen} options={{tabBarIcon: ({focused, color}) => {
         return(
          <MaterialCommunityIcons name="account-circle" size={24} color={color} />);
          }}} />

              <Tab.Screen name="Infor" component={InformationScreen} options={{tabBarIcon: ({focused, color}) => {
                  return(
                    <MaterialCommunityIcons name="information" size={24} color={color}/>);
                     }}} />  
            <Tab.Screen name="Menu
            
            " component={MenuScreen} options={{tabBarIcon: ({focused, color}) => {
              return(
                <MaterialCommunityIcons name="" size={24} color={color} />);
                }}} />

        </Tab.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}

export default App;
