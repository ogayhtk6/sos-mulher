import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

export default function InformationScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Settings Screen</Text>
    </View>
  );
}

