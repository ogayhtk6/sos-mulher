import React from 'react';
import { View } from 'react-native';
import { Button, Text,Image } from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons'; 
import { Ionicons } from '@expo/vector-icons'; 



export default function HomeScreen() {
  return (
    <View style={{flex:1,flexDirection:'column',justifyContent:'flex-start'}}>  
    <View style={{flex:1}} >
    
    <Image style={{height:400, width: 500}} source={require('./imagem_path.png')} />
    
    </View>

    <View style={{ flex: 1,flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' }}>
      
      <Button mode="contained">
      <MaterialIcons name="supervisor-account" size={110} color="color" />
      </Button>

      <Button mode="contained">
      <Ionicons name="megaphone" size={110} color="Color" />
      </Button>
    </View>

  <View style={{flex:1}} ></View>

        <View style={{ flex: 1,flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' }}>
      <Button mode="contained">
      <MaterialIcons name="call" size={110} color="color" />
      </Button>

            <Button mode="contained">
      <MaterialIcons name="call" size={110} color="color" />
      </Button>
    </View>
     <View style={{flex:1}} ></View>

    </View>

  );
}