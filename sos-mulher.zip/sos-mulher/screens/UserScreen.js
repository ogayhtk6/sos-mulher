import React from 'react';
import { View } from 'react-native';
import { Button, Text, Appbar,Image } from 'react-native-paper';
import { StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons'; 




function HomeScreen({ navigation }) {
  return (
    <View>
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>   

      <Text>Home Screen</Text>
      <Button mode="contained" icon="supervisor-account">
      <MaterialIcons name="supervisor-account" size={24} color="color" />
      </Button>
    </View>


<View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>   

      <Text>test</Text>
      <Button mode="contained" icon="supervisor-account">
      <MaterialIcons name="supervisor-account" size={24} color="color" />
      </Button>
    </View>
    </View>
  );
}

export default HomeScreen;
