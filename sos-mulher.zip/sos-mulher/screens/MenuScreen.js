import React, { useState, useEffect } from 'react';
import { View, FlatList } from 'react-native';
import { ActivityIndicator, List } from 'react-native-paper';

function UserListScreen() {
  const [isLoading, setLoading] = useState(true);
  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    try {
      const response = await fetch('https://jsonplaceholder.typicode.com/users');
      const json = await response.json();
      setUsers(json);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getUsers();
  }, []);

  return (
    <View style={{ flex: 1 }}>
      <ActivityIndicator animating={isLoading} />
      <FlatList
        data={users}
        renderItem={({ item }) => <List.Item title={item.name} />}
      />
    </View>
  );
}

export default UserListScreen;
